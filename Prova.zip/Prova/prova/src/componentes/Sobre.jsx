export default function Sobre(){
    return(
        <div class="sobre">
            <div class="texto">
            <h2>
                Halloween
            </h2>
            <p>
            O Halloween, ou Dia das Bruxas, é uma tradicional festa norte-americana que surgiu nas Ilhas Britânicas e é 
            reproduzida em diferentes países, inclusive no Brasil. Essa festa é marcada por crianças que se fantasiam 
            de monstros e saem à procura de doces. Aqui no Brasil é comumente conhecida como Dia das Bruxas.
            </p>
            <br />
            <p>Data: 31/10/2024 das 10:00 até 12:40 </p>
            <p>Local: Escola SesiSenai São José</p>
            <br />
            <button class="botao">Inscrição</button>
            </div>
            <div>
            <img class="imgs" src="Abobora.png" alt="" />
            </div>
        </div>
    )
}

export default function Footer(){
    return(
        <div class="footer">
            <footer class="text">
                <h3>Juliano Tavares da Silva 3C</h3>
            </footer>
        </div>
    )
}
export default function Header(){
    return(
        <header class="header">
            <img class="imgh" src="Senai.png" alt="" />
        </header>
    )
}
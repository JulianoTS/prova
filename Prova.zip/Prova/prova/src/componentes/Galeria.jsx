export default function Galeria(){
    return(
        <div>
            <section class="imagens">
                <img class="halloween" src="halloween1.PNG"></img>
                <img class="halloween" src="halloween4.PNG"></img>
                <img class="halloween" src="halloween2.PNG"></img>
            </section>
            <br />
            <br />
            <br />
            <section class="imagens">
                <img class="halloween" src="halloween3.PNG"></img>
                <img class="halloween" src="halloween5.PNG"></img>
                <img class="halloween" src="halloween6.PNG"></img>
            </section>
            <br />
        </div>
    )
}
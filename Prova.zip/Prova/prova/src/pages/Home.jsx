import React from 'react'
import "../sytles/sytles.css"
import Header from '../componentes/Header'
import Sobre from '../componentes/Sobre'
import Galeria from '../componentes/Galeria'
import Footer from '../componentes/Footer'

function Home() {
    return (
        <div>
            <Header />
            <Sobre />
            <Galeria />
            <Footer />
        </div>        
  )
}

export default Home